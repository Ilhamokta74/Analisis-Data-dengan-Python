# Bike Sharing Dashboard

## Setup environment
```
conda create --name main-ds python=3.11.4
conda activate main-ds
pip install streamlit pandas matplotlib numpy seaborn plotly
```

## Run steamlit app
```
streamlit run dashboard.py
```
